"""
db_config.py
------------
Centralized MySQL (XAMPP) connection settings.

Before running the app:
1. Start Apache + MySQL from the XAMPP Control Panel.
2. Open phpMyAdmin (http://localhost/phpmyadmin) and import
   database/schema.sql (or run it in the MySQL console).
3. Keep these values matching your XAMPP MySQL setup. The
   defaults below match a stock XAMPP install.
"""

import mysql.connector
from mysql.connector import Error

DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "",          # default XAMPP MySQL root password is empty
    "database": "smart_supermarket",
}


def get_connection():
    """
    Opens and returns a new MySQL connection.
    Raises a ConnectionError with a friendly message if XAMPP's
    MySQL service isn't running or the database doesn't exist yet.
    """
    try:
        connection = mysql.connector.connect(**DB_CONFIG)
        return connection
    except Error as e:
        raise ConnectionError(
            "Database connection failed. Please check that:\n"
            "1) XAMPP's MySQL service is running,\n"
            "2) the 'smart_supermarket' database has been created "
            "(import database/schema.sql via phpMyAdmin),\n"
            "3) the credentials in db_config.py match your XAMPP setup.\n\n"
            f"Original error: {e}"
        )
