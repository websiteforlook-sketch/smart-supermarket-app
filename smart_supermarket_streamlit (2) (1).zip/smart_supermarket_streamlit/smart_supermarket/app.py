
"""
app.py
------
Main Streamlit application. Run with:  streamlit run app.py
 
Handles: language switch, login/register/forgot-password screens,
sidebar navigation, and the Dashboard / Products / Sales /
History / Analytics / Reports pages.
"""
 
import streamlit as st
import pandas as pd
import plotly.express as px
import base64
import os
import io
from PIL import Image
 
from translations import get_text
from auth_utils import (
    register_user, login_user, reset_password,
    update_profile, change_password, update_profile_picture,
)
from products import (
    add_product, get_products, get_product_by_id,
    update_product, delete_product, get_low_stock_products,
)
from sales import (
    record_sale, get_sales_history, get_dashboard_stats,
    get_revenue_over_time, get_top_selling_products, get_monthly_revenue,
)
 
st.set_page_config(page_title="Smart Supermarket", page_icon="🛒", layout="wide")
 
# ---------------------------------------------------------- header image ----
# Aa image "assets/header_image.png" folder ma hovi joie (app.py ni baju ma).
HEADER_IMAGE_PATH = os.path.join(os.path.dirname(__file__), "assets", "header_image.png")
 
 
def get_base64_image(path):
    if not os.path.exists(path):
        return None
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode()
 
 
HEADER_IMAGE_B64 = get_base64_image(HEADER_IMAGE_PATH)
 
 
def get_avatar_html(user, size=60):
    """Returns an <img>/<div> avatar: user's uploaded photo > header image > initials circle.
    The photo (when there is one) is wrapped in a link, so clicking it opens
    the full-size image in a new browser tab."""
    if user and user.get("profile_pic"):
        pic_b64 = base64.b64encode(user["profile_pic"]).decode()
        src = f"data:image/jpeg;base64,{pic_b64}"
        return (
            f'<a href="{src}" target="_blank" title="Photo jovo/View photo">'
            f'<img src="{src}" '
            f'style="width:{size}px;height:{size}px;border-radius:50%;object-fit:cover;'
            f'box-shadow:0 2px 8px rgba(0,0,0,0.25);cursor:pointer;" /></a>'
        )
    if HEADER_IMAGE_B64:
        src = f"data:image/png;base64,{HEADER_IMAGE_B64}"
        return (
            f'<a href="{src}" target="_blank" title="Photo jovo/View photo">'
            f'<img src="{src}" '
            f'style="width:{size}px;height:{size}px;border-radius:50%;object-fit:cover;'
            f'box-shadow:0 2px 8px rgba(0,0,0,0.25);cursor:pointer;" /></a>'
        )
    initial = (user["shop_name"][:1].upper() if user else "?")
    return (
        f'<div style="width:{size}px;height:{size}px;border-radius:50%;background:{HERO_COLOR_1};'
        f'display:flex;align-items:center;justify-content:center;color:white;'
        f'font-size:{int(size*0.4)}px;font-weight:700;">{initial}</div>'
    )
 
 
def show_user_hero_banner(user):
    """Same style as the login welcome banner, but shows THIS logged-in
    user's own uploaded photo (falls back to header image / initials)."""
    icon_html = get_avatar_html(user, size=110)
    st.markdown(
        f"""
        <div class="hero-banner">
          <div class="hero-icon" style="display:flex;">{icon_html}</div>
          <div>
            <h1>{t('welcome')}, {user['shop_name']}!</h1>
            <p>{t('tagline_welcome')}</p>
          </div>
        </div>
        """,
        unsafe_allow_html=True,
    )
 
 
def page_header(title, user):
    """Shows a page title with the user's medium-size avatar next to it."""
    st.markdown(
        f"""
        <div style="display:flex;align-items:center;gap:0.8rem;margin-bottom:0.5rem;">
            {get_avatar_html(user, size=48)}
            <h2 style="margin:0;">{title}</h2>
        </div>
        """,
        unsafe_allow_html=True,
    )
 
# ------------------------------------------------------------- session ----
if "lang" not in st.session_state:
    st.session_state.lang = "gu"
if "user" not in st.session_state:
    st.session_state.user = None
if "auth_view" not in st.session_state:
    st.session_state.auth_view = "login"   # login | register | forgot
 
lang = st.session_state.lang
 
 
def t(key):
    return get_text(lang, key)
 
 
def flash(kind, message):
    """Stash a success/error message so it survives the st.rerun() that follows."""
    st.session_state["_flash"] = (kind, message)
 
 
def show_flash():
    """Show (and clear) any message stashed by flash(). Call at the top of a page."""
    if "_flash" in st.session_state:
        kind, message = st.session_state.pop("_flash")
        if kind == "success":
            st.success(message)
        else:
            st.error(message)
 
 
# ------------------------------------------------------------- styling ----
# 👇 Aa colors badlo tamari marji pramane. Hex code online
# "color picker" search karine kadhi shakay chhe.
BACKGROUND_TOP = "#FFFFFF"      # page background - upar no color (white, matches your banner)
BACKGROUND_BOTTOM = "#EAF2FF"   # page background - niche no color (soft light blue)
HERO_COLOR_1 = "#0B1F3F"        # welcome banner - gradient start (navy)
HERO_COLOR_2 = "#1D4ED8"        # welcome banner - gradient end (blue)
ACCENT = "#F5A623"              # orange/gold accent (buttons, active tab) - matches cart logo
TEXT_DARK = "#0B1F3F"           # normal readable text color (navy)
 
st.markdown(
    f"""
    <style>
    .stApp {{
        background: linear-gradient(160deg, {BACKGROUND_TOP} 0%, {BACKGROUND_BOTTOM} 100%);
    }}
 
    /* ---- readable text everywhere (fixes invisible white-on-light text) ---- */
    h1, h2, h3, h4, p, label, span, .stMarkdown, .stCaption {{
        color: {TEXT_DARK} !important;
    }}
 
    /* ---- hero / welcome banner ---- */
    .hero-banner {{
        background: linear-gradient(120deg, {HERO_COLOR_1} 0%, {HERO_COLOR_2} 100%);
        border-radius: 18px;
        padding: 2.2rem 2rem;
        margin-bottom: 1.5rem;
        display: flex;
        flex-direction: row-reverse;
        align-items: center;
        justify-content: flex-end;
        gap: 1.5rem;
        box-shadow: 0 8px 24px rgba(18,61,41,0.18);
    }}
    .hero-banner > div:last-child {{ text-align: right; }}
    .hero-banner h1 {{
        color: #FFFFFF !important;
        font-size: 1.9rem;
        margin: 0 0 0.3rem 0;
    }}
    .hero-banner p {{
        color: #E7F0E9 !important;
        margin: 0;
        font-size: 0.98rem;
    }}
    .hero-icon svg {{ width: 110px; height: 110px; flex-shrink: 0; }}
 
    /* ---- input boxes: force light background + dark readable text ---- */
    .stTextInput > div > div > input,
    .stNumberInput > div > div > input,
    .stSelectbox > div > div {{
        background-color: #FFFFFF !important;
        color: {TEXT_DARK} !important;
        border: 1px solid #D8D2C2 !important;
        border-radius: 8px !important;
    }}
 
    /* ---- tabs ---- */
    .stTabs [data-baseweb="tab"] {{
        color: {TEXT_DARK} !important;
        font-weight: 500;
    }}
    .stTabs [aria-selected="true"] {{
        color: {HERO_COLOR_2} !important;
        border-bottom-color: {HERO_COLOR_2} !important;
    }}
 
    /* ---- buttons ---- */
    .stButton > button, .stFormSubmitButton > button, .stDownloadButton > button {{
        background-color: {HERO_COLOR_2} !important;
        color: #FFFFFF !important;
        border-radius: 999px !important;
        border: none !important;
        font-weight: 600;
    }}
    .stButton > button:hover, .stFormSubmitButton > button:hover, .stDownloadButton > button:hover {{
        background-color: {HERO_COLOR_1} !important;
    }}
    /* fix: button label text (p/span/div inside button) was inheriting the
       dark page-text color and becoming invisible on the dark button */
    .stButton > button *, .stFormSubmitButton > button *, .stDownloadButton > button * {{
        color: #FFFFFF !important;
    }}
 
    .metric-card {{
        background: #FFFFFF;
        border: 1px solid #D8D2C2;
        border-top: 3px solid {HERO_COLOR_2};
        border-radius: 10px;
        padding: 0.9rem 0.8rem;
        min-height: 92px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        overflow-wrap: break-word;
        word-break: break-word;
    }}
    .metric-card .metric-label {{
        font-size: 0.72rem;
        opacity: 0.75;
        margin-bottom: 0.3rem;
        line-height: 1.2;
    }}
    .metric-card .metric-value {{
        font-size: clamp(1.05rem, 2.2vw, 1.5rem);
        font-weight: 700;
        line-height: 1.2;
        white-space: nowrap;
    }}
    .low-stock-row {{ background-color: #FBEAE3 !important; }}
 
    /* ---- file uploader: light theme instead of Streamlit's default dark box ---- */
    [data-testid="stFileUploaderDropzone"] {{
        background-color: #F3F6FB !important;
        border: 1.5px dashed {HERO_COLOR_2} !important;
        border-radius: 12px !important;
    }}
    [data-testid="stFileUploaderDropzone"] * {{
        color: {TEXT_DARK} !important;
    }}
    [data-testid="stFileUploaderDropzone"] button {{
        background-color: {HERO_COLOR_2} !important;
        color: #FFFFFF !important;
        border-radius: 999px !important;
        border: none !important;
    }}
    [data-testid="stFileUploaderDropzone"] button * {{
        color: #FFFFFF !important;
    }}
    section[data-testid="stSidebar"] {{ background-color: {HERO_COLOR_1}; }}
    section[data-testid="stSidebar"] * {{ color: #F7F5EF !important; }}
 
    /* ---- fix: sidebar dropdown (language selector) has a white box,
       so its own text must stay dark, not light-on-light ---- */
    section[data-testid="stSidebar"] .stSelectbox > div > div,
    section[data-testid="stSidebar"] .stSelectbox [data-baseweb="select"] *,
    section[data-testid="stSidebar"] div[data-baseweb="popover"] * {{
        color: {TEXT_DARK} !important;
    }}
    </style>
    """,
    unsafe_allow_html=True,
)
 
 
def show_hero_banner():
    """A welcome banner with your uploaded header image (falls back to an SVG icon)."""
    if HEADER_IMAGE_B64:
        icon_html = (
            f'<img src="data:image/png;base64,{HEADER_IMAGE_B64}" '
            f'style="width:160px;height:auto;border-radius:14px;'
            f'box-shadow:0 8px 20px rgba(0,0,0,0.25);object-fit:cover;" />'
        )
    else:
        icon_html = """
            <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="32" cy="32" r="30" fill="#ffffff" opacity="0.12"/>
              <path d="M10 14h5l4.2 24.4a4 4 0 0 0 3.9 3.3h20a4 4 0 0 0 3.9-3.2L51 22H16"
                    stroke="#ffffff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
              <circle cx="24" cy="50" r="3.2" fill="#F5A623"/>
              <circle cx="42" cy="50" r="3.2" fill="#F5A623"/>
              <path d="M24 22v-3a6 6 0 0 1 12 0v3" stroke="#F5A623" stroke-width="3" stroke-linecap="round" fill="none"/>
            </svg>
        """
    st.markdown(
        f"""
        <div class="hero-banner">
          <div class="hero-icon">{icon_html}</div>
          <div>
            <h1>Welcome to Smart Inventory Management System</h1>
            <p>{t('tagline_welcome')}</p>
          </div>
        </div>
        """,
        unsafe_allow_html=True,
    )
 
 
# ============================================================ AUTH VIEW ====
def show_language_toggle():
    col1, col2 = st.columns([6, 1])
    with col2:
        choice = st.selectbox(
            t("language"), options=["gu", "en"],
            format_func=lambda x: "ગુજરાતી" if x == "gu" else "English",
            index=0 if lang == "gu" else 1,
            key="lang_selector_auth",
            label_visibility="collapsed",
        )
        if choice != st.session_state.lang:
            st.session_state.lang = choice
            st.rerun()
 
 
def login_screen():
    show_hero_banner()
    show_language_toggle()
 
    tab_login, tab_register, tab_forgot = st.tabs([t("login"), t("register"), t("forgot_password")])
 
    with tab_login:
        with st.form("login_form"):
            email = st.text_input(t("email"))
            password = st.text_input(t("password"), type="password")
            submitted = st.form_submit_button(t("login_btn"), use_container_width=True)
            if submitted:
                success, message, user = login_user(email, password)
                if success:
                    st.session_state.user = user
                    st.success(message)
                    st.rerun()
                else:
                    st.error(message)
 
    with tab_register:
        with st.form("register_form"):
            shop_name = st.text_input(t("shop_name"))
            username = st.text_input(t("username"))
            mobile_no = st.text_input(t("mobile_no"))
            email_r = st.text_input(t("email"), key="reg_email")
            password_r = st.text_input(t("password"), type="password", key="reg_password")
            submitted = st.form_submit_button(t("register_btn"), use_container_width=True)
            if submitted:
                success, message = register_user(shop_name, username, mobile_no, email_r, password_r)
                if success:
                    st.success(message)
                else:
                    st.error(message)
 
    with tab_forgot:
        with st.form("forgot_form"):
            email_f = st.text_input(t("email"), key="forgot_email")
            username_f = st.text_input(t("username"), key="forgot_username")
            new_password = st.text_input(t("new_password"), type="password", key="forgot_new_pw")
            submitted = st.form_submit_button(t("reset_btn"), use_container_width=True)
            if submitted:
                success, message = reset_password(email_f, username_f, new_password)
                if success:
                    st.success(message)
                else:
                    st.error(message)
 
 
# ======================================================= MAIN APPLICATION ====
def dashboard_page(user_id, user):
    show_flash()
    show_user_hero_banner(user)
    st.subheader(t("dashboard_title"))
    stats = get_dashboard_stats(user_id)
 
    c1, c2, c3, c4, c5 = st.columns(5)
    for col, label, value in zip(
        [c1, c2, c3, c4, c5],
        [t("total_products"), t("available_stock"), t("total_sales"), t("total_revenue"), t("total_profit")],
        [stats["total_products"], stats["available_stock"], stats["total_sales"],
         f"₹{stats['total_revenue']:,.0f}", f"₹{stats['total_profit']:,.0f}"],
    ):
        with col:
            st.markdown(
                f'<div class="metric-card"><div class="metric-label">{label}</div>'
                f'<div class="metric-value">{value}</div></div>',
                unsafe_allow_html=True,
            )
 
    st.subheader(t("low_stock_alert"))
    low_stock_df = get_low_stock_products(user_id)
    if low_stock_df.empty:
        st.info(t("no_low_stock"))
    else:
        st.dataframe(
            low_stock_df[["name", "category", "quantity", "low_stock_threshold"]],
            use_container_width=True, hide_index=True,
        )
 
 
def products_page(user_id, user):
    page_header(t("products_title"), user)
    show_flash()
    tab_view, tab_add, tab_edit, tab_delete = st.tabs(
        [t("view_products"), t("add_product"), t("edit_product"), t("delete_product")]
    )
 
    with tab_view:
        df = get_products(user_id)
        if df.empty:
            st.info(t("no_products_yet"))
        else:
            display_df = df[
                ["id", "name", "category", "cost_price", "price", "quantity", "low_stock_threshold"]
            ].rename(columns={
                "cost_price": t("purchase_price"),
                "price": t("selling_price"),
                "name": t("product_name"),
                "category": t("category"),
                "quantity": t("quantity"),
                "low_stock_threshold": t("low_stock_threshold"),
            })
            st.dataframe(display_df, use_container_width=True, hide_index=True)
 
    with tab_add:
        with st.form("add_product_form", clear_on_submit=True):
            name = st.text_input(t("product_name"))
            category = st.text_input(t("category"))
            c1, c2 = st.columns(2)
            with c1:
                cost_price = st.number_input(t("purchase_price"), min_value=0.0, step=1.0)
            with c2:
                price = st.number_input(t("selling_price"), min_value=0.0, step=1.0)
            c3, c4 = st.columns(2)
            with c3:
                quantity = st.number_input(t("quantity"), min_value=0, step=1)
            with c4:
                threshold = st.number_input(t("low_stock_threshold"), min_value=0, step=1, value=5)
            submitted = st.form_submit_button(t("save"), use_container_width=True)
            if submitted:
                success, message = add_product(user_id, name, category, price, cost_price, quantity, threshold)
                if success:
                    flash("success", message)
                    st.rerun()
                else:
                    st.error(message)
 
    with tab_edit:
        df = get_products(user_id)
        if df.empty:
            st.info(t("no_products_yet"))
        else:
            options = {f"{row['name']} (#{row['id']})": row["id"] for _, row in df.iterrows()}
            selected_label = st.selectbox(t("select_product_edit"), list(options.keys()))
            product = get_product_by_id(options[selected_label], user_id)
            if product:
                with st.form("edit_product_form"):
                    name = st.text_input(t("product_name"), value=product["name"])
                    category = st.text_input(t("category"), value=product["category"])
                    c1, c2 = st.columns(2)
                    with c1:
                        cost_price = st.number_input(t("purchase_price"), min_value=0.0, step=1.0, value=float(product["cost_price"]))
                    with c2:
                        price = st.number_input(t("selling_price"), min_value=0.0, step=1.0, value=float(product["price"]))
                    c3, c4 = st.columns(2)
                    with c3:
                        quantity = st.number_input(t("quantity"), min_value=0, step=1, value=int(product["quantity"]))
                    with c4:
                        threshold = st.number_input(t("low_stock_threshold"), min_value=0, step=1, value=int(product["low_stock_threshold"]))
                    submitted = st.form_submit_button(t("update"), use_container_width=True)
                    if submitted:
                        success, message = update_product(
                            product["id"], user_id, name, category, price, cost_price, quantity, threshold
                        )
                        if success:
                            flash("success", message)
                            st.rerun()
                        else:
                            st.error(message)
 
    with tab_delete:
        df = get_products(user_id)
        if df.empty:
            st.info(t("no_products_yet"))
        else:
            options = {f"{row['name']} (#{row['id']})": row["id"] for _, row in df.iterrows()}
            selected_label = st.selectbox(t("select_product_delete"), list(options.keys()), key="delete_select")
            confirm = st.checkbox(t("confirm_delete"))
            if st.button(t("delete"), type="primary", disabled=not confirm):
                success, message = delete_product(options[selected_label], user_id)
                if success:
                    flash("success", message)
                    st.rerun()
                else:
                    st.error(message)
 
 
def sales_page(user_id, user):
    page_header(t("sales_title"), user)
    show_flash()
    df = get_products(user_id)
 
    if df.empty:
        st.info(t("no_products_yet"))
        return
 
    with st.form("record_sale_form", clear_on_submit=True):
        options = {f"{row['name']} — {row['quantity']} left (₹{row['price']})": row["id"] for _, row in df.iterrows()}
        selected_label = st.selectbox(t("select_product"), list(options.keys()))
        quantity_sold = st.number_input(t("qty_sold"), min_value=1, step=1)
        submitted = st.form_submit_button(t("record_sale"), use_container_width=True)
        if submitted:
            success, message = record_sale(user_id, options[selected_label], quantity_sold)
            if success:
                flash("success", message)
                st.rerun()
            else:
                st.error(message)
 
 
def history_page(user_id, user):
    page_header(t("history_title"), user)
    df = get_sales_history(user_id)
    if df.empty:
        st.info(t("no_sales_yet"))
    else:
        display_df = df.rename(columns={
            "id": "ID", "product_name": t("product_name"),
            "quantity_sold": t("qty_sold"), "sale_amount": t("sale_amount"),
            "profit": t("profit"), "sale_date": t("sale_date"),
        })
        st.dataframe(display_df, use_container_width=True, hide_index=True)
 
 
def analytics_page(user_id, user):
    page_header(t("analytics_title"), user)
    sales_df = get_sales_history(user_id)
 
    if sales_df.empty:
        st.info(t("no_sales_yet"))
        return
 
    st.subheader(t("revenue_over_time"))
    revenue_df = get_revenue_over_time(user_id)
    if not revenue_df.empty:
        fig1 = px.line(revenue_df, x="sale_day", y="revenue", markers=True,
                        color_discrete_sequence=["#1F6F4A"])
        fig1.update_layout(xaxis_title=t("sale_date"), yaxis_title=t("total_revenue"))
        st.plotly_chart(fig1, use_container_width=True)
 
    st.subheader(t("top_selling"))
    top_df = get_top_selling_products(user_id)
    if not top_df.empty:
        fig2 = px.bar(top_df, x="product_name", y="total_quantity",
                       color_discrete_sequence=["#E0A526"])
        fig2.update_layout(xaxis_title=t("product_name"), yaxis_title=t("qty_sold"))
        st.plotly_chart(fig2, use_container_width=True)
 
    st.subheader(t("monthly_revenue"))
    monthly_df = get_monthly_revenue(user_id)
    if not monthly_df.empty:
        fig3 = px.bar(monthly_df, x="month", y=["revenue", "profit"], barmode="group",
                       color_discrete_sequence=["#1F6F4A", "#C6512B"])
        st.plotly_chart(fig3, use_container_width=True)
 
 
def reports_page(user_id, user):
    page_header(t("reports_title"), user)
    df = get_sales_history(user_id)
    if df.empty:
        st.info(t("no_sales_yet"))
        return
 
    display_df = df.rename(columns={
        "id": "Sale ID", "product_name": "Product",
        "quantity_sold": "Quantity", "sale_amount": "Sale Amount",
        "profit": "Profit", "sale_date": "Date",
    })
    st.dataframe(display_df, use_container_width=True, hide_index=True)
 
    csv_bytes = display_df.to_csv(index=False).encode("utf-8")
    st.download_button(
        t("download_csv"), data=csv_bytes,
        file_name="sales_report.csv", mime="text/csv",
        use_container_width=True,
    )
 
 
def profile_page(user):
    page_header(t("profile_title"), user)
    show_flash()
 
    col_left, col_right = st.columns([1, 2])
    with col_left:
        if user.get("profile_pic"):
            st.image(io.BytesIO(user["profile_pic"]), width=180)
        elif HEADER_IMAGE_B64:
            st.markdown(
                f'<img src="data:image/png;base64,{HEADER_IMAGE_B64}" '
                f'style="width:100%;border-radius:14px;" />',
                unsafe_allow_html=True,
            )
        else:
            st.markdown(
                f"""
                <div style="width:120px;height:120px;border-radius:50%;
                            background:{HERO_COLOR_1};display:flex;align-items:center;
                            justify-content:center;font-size:2.4rem;color:white;">
                    {user['shop_name'][:1].upper()}
                </div>
                """,
                unsafe_allow_html=True,
            )
        st.caption(f"**{t('username')}:** {user['username']}")
 
        uploaded_photo = st.file_uploader(
            t("upload_photo"), type=["png", "jpg", "jpeg"], key="profile_pic_uploader"
        )
        if uploaded_photo is not None:
            if st.button(t("save_photo"), use_container_width=True):
                img = Image.open(uploaded_photo).convert("RGB")
                img.thumbnail((400, 400))  # keep file size small
                buf = io.BytesIO()
                img.save(buf, format="JPEG", quality=85)
                success, message = update_profile_picture(user["id"], buf.getvalue())
                if success:
                    st.session_state.user["profile_pic"] = buf.getvalue()
                    flash("success", message)
                    st.rerun()
                else:
                    st.error(message)
 
    with col_right:
        st.subheader(t("edit_profile"))
        with st.form("edit_profile_form"):
            shop_name = st.text_input(t("shop_name"), value=user["shop_name"])
            mobile_no = st.text_input(t("mobile_no"), value=user["mobile_no"])
            email = st.text_input(t("email"), value=user["email"])
            submitted = st.form_submit_button(t("save_changes"), use_container_width=True)
            if submitted:
                success, message, updated_user = update_profile(user["id"], shop_name, mobile_no, email)
                if success:
                    st.session_state.user = updated_user
                    flash("success", message)
                    st.rerun()
                else:
                    st.error(message)
 
        st.divider()
        st.subheader(t("change_password_title"))
        with st.form("change_password_form", clear_on_submit=True):
            current_password = st.text_input(t("current_password"), type="password")
            new_password = st.text_input(t("new_password"), type="password")
            submitted_pw = st.form_submit_button(t("update_password_btn"), use_container_width=True)
            if submitted_pw:
                success, message = change_password(user["id"], current_password, new_password)
                if success:
                    st.success(message)
                else:
                    st.error(message)
 
 
# ==================================================================== MAIN ====
def main_app():
    user = st.session_state.user
    with st.sidebar:
        st.markdown(
            f"""
            <div style="display:flex;align-items:center;gap:0.7rem;margin-bottom:0.5rem;">
                {get_avatar_html(user, size=56)}
                <div>
                    <div style="font-weight:700;font-size:1rem;">{t('app_title')}</div>
                    <div style="font-size:0.8rem;opacity:0.85;">{t('welcome')}, {user['shop_name']}</div>
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        st.caption(f"{user['username']}")
 
        page = st.radio(
            "nav",
            [t("nav_dashboard"), t("nav_products"), t("nav_sales"),
             t("nav_history"), t("nav_analytics"), t("nav_reports"), t("nav_profile")],
            label_visibility="collapsed",
        )
 
        st.divider()
        lang_choice = st.selectbox(
            t("language"), options=["gu", "en"],
            format_func=lambda x: "ગુજરાતી" if x == "gu" else "English",
            index=0 if lang == "gu" else 1,
        )
        if lang_choice != st.session_state.lang:
            st.session_state.lang = lang_choice
            st.rerun()
 
        if st.button(t("nav_logout"), use_container_width=True):
            st.session_state.user = None
            st.rerun()
 
    user_id = user["id"]
    if page == t("nav_dashboard"):
        dashboard_page(user_id, user)
    elif page == t("nav_products"):
        products_page(user_id, user)
    elif page == t("nav_sales"):
        sales_page(user_id, user)
    elif page == t("nav_history"):
        history_page(user_id, user)
    elif page == t("nav_analytics"):
        analytics_page(user_id, user)
    elif page == t("nav_reports"):
        reports_page(user_id, user)
    elif page == t("nav_profile"):
        profile_page(user)
 
 
# --------------------------------------------------------------- router ----
if st.session_state.user is None:
    login_screen()
else:
    main_app()
