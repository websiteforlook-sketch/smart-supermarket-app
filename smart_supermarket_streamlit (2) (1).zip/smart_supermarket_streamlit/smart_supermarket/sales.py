"""
sales.py
--------
Sales recording, sales history, and analytics/report data.
record_sale() runs the stock-update + sale-insert as one MySQL
transaction so stock and sales records never get out of sync.
"""

import pandas as pd
from mysql.connector import Error
from db_config import get_connection


def record_sale(user_id, product_id, quantity_sold):
    """
    Validates stock, then atomically:
      1. reduces product quantity
      2. inserts the sales row
    Returns (success: bool, message: str)
    """
    try:
        quantity_sold = int(quantity_sold)
    except (TypeError, ValueError):
        return False, "Quantity must be a whole number."

    if quantity_sold <= 0:
        return False, "Quantity sold must be greater than zero."

    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor(dictionary=True)

        # Lock the product row for this transaction to avoid race conditions
        conn.start_transaction()
        cursor.execute(
            "SELECT * FROM products WHERE id = %s AND user_id = %s FOR UPDATE",
            (product_id, user_id),
        )
        product = cursor.fetchone()

        if not product:
            conn.rollback()
            return False, "Product not found."

        if quantity_sold > product["quantity"]:
            conn.rollback()
            return False, f"Not enough stock. Only {product['quantity']} unit(s) available."

        sale_amount = float(product["price"]) * quantity_sold
        profit = (float(product["price"]) - float(product["cost_price"])) * quantity_sold

        cursor.execute(
            "UPDATE products SET quantity = quantity - %s WHERE id = %s AND user_id = %s",
            (quantity_sold, product_id, user_id),
        )
        cursor.execute(
            """
            INSERT INTO sales (user_id, product_id, quantity_sold, sale_amount, profit)
            VALUES (%s, %s, %s, %s, %s)
            """,
            (user_id, product_id, quantity_sold, sale_amount, profit),
        )
        conn.commit()
        return True, f"Sale recorded. Amount: {sale_amount:.2f}, Profit: {profit:.2f}"

    except Error as e:
        if conn is not None:
            conn.rollback()
        return False, f"Database error while recording sale: {e}"
    except ConnectionError as e:
        return False, str(e)
    finally:
        if conn is not None and conn.is_connected():
            conn.close()


def get_sales_history(user_id) -> pd.DataFrame:
    """
    Columns: id, product_name, quantity_sold, sale_amount, profit, sale_date
    """
    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute(
            """
            SELECT s.id, p.name AS product_name, s.quantity_sold,
                   s.sale_amount, s.profit, s.sale_date
            FROM sales s
            JOIN products p ON p.id = s.product_id
            WHERE s.user_id = %s
            ORDER BY s.sale_date DESC
            """,
            (user_id,),
        )
        return pd.DataFrame(cursor.fetchall())
    except (Error, ConnectionError):
        return pd.DataFrame()
    finally:
        if conn is not None and conn.is_connected():
            conn.close()


def get_dashboard_stats(user_id) -> dict:
    conn = None
    stats = {
        "total_products": 0,
        "available_stock": 0,
        "total_sales": 0,
        "total_revenue": 0.0,
        "total_profit": 0.0,
    }
    try:
        conn = get_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute(
            "SELECT COUNT(*) AS cnt, COALESCE(SUM(quantity),0) AS stock "
            "FROM products WHERE user_id = %s",
            (user_id,),
        )
        row = cursor.fetchone()
        stats["total_products"] = row["cnt"]
        stats["available_stock"] = int(row["stock"])

        cursor.execute(
            "SELECT COALESCE(SUM(quantity_sold),0) AS qty, "
            "COALESCE(SUM(sale_amount),0) AS revenue, "
            "COALESCE(SUM(profit),0) AS profit "
            "FROM sales WHERE user_id = %s",
            (user_id,),
        )
        row = cursor.fetchone()
        stats["total_sales"] = int(row["qty"])
        stats["total_revenue"] = float(row["revenue"])
        stats["total_profit"] = float(row["profit"])

        return stats
    except (Error, ConnectionError):
        return stats
    finally:
        if conn is not None and conn.is_connected():
            conn.close()


def get_revenue_over_time(user_id) -> pd.DataFrame:
    """Columns: sale_day, revenue"""
    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute(
            """
            SELECT DATE(sale_date) AS sale_day, SUM(sale_amount) AS revenue
            FROM sales WHERE user_id = %s
            GROUP BY DATE(sale_date)
            ORDER BY sale_day
            """,
            (user_id,),
        )
        return pd.DataFrame(cursor.fetchall())
    except (Error, ConnectionError):
        return pd.DataFrame()
    finally:
        if conn is not None and conn.is_connected():
            conn.close()


def get_top_selling_products(user_id, limit=8) -> pd.DataFrame:
    """Columns: product_name, total_quantity"""
    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute(
            """
            SELECT p.name AS product_name, SUM(s.quantity_sold) AS total_quantity
            FROM sales s
            JOIN products p ON p.id = s.product_id
            WHERE s.user_id = %s
            GROUP BY p.name
            ORDER BY total_quantity DESC
            LIMIT %s
            """,
            (user_id, limit),
        )
        return pd.DataFrame(cursor.fetchall())
    except (Error, ConnectionError):
        return pd.DataFrame()
    finally:
        if conn is not None and conn.is_connected():
            conn.close()


def get_monthly_revenue(user_id) -> pd.DataFrame:
    """Columns: month, revenue, profit"""
    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute(
            """
            SELECT DATE_FORMAT(sale_date, '%%Y-%%m') AS month,
                   SUM(sale_amount) AS revenue, SUM(profit) AS profit
            FROM sales WHERE user_id = %s
            GROUP BY month
            ORDER BY month
            """,
            (user_id,),
        )
        return pd.DataFrame(cursor.fetchall())
    except (Error, ConnectionError):
        return pd.DataFrame()
    finally:
        if conn is not None and conn.is_connected():
            conn.close()
