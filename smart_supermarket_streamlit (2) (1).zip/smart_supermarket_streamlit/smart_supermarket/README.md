# Smart Supermarket Inventory & Sales Analytics System
### Diploma Computer Engineering Minor Project — Streamlit + MySQL (XAMPP)

---

## 1. Project Structure

```
smart_supermarket/
│
├── app.py                # Main Streamlit app (UI + navigation)
├── auth_utils.py          # Register / Login / Forgot-password logic
├── db_config.py            # Centralized MySQL connection settings
├── products.py              # Product CRUD + low-stock logic
├── sales.py                  # Sale recording + analytics queries
├── translations.py            # Gujarati / English text dictionary
├── database/
│   └── schema.sql               # MySQL table definitions
├── requirements.txt
└── README.md
```

---

## 2. XAMPP + phpMyAdmin Database Setup

1. **Open XAMPP Control Panel**, click **Start** next to `Apache` and `MySQL`.
2. Open your browser and go to **http://localhost/phpmyadmin**
3. Click the **Import** tab (top menu).
4. Click **Choose File**, select `database/schema.sql` from this project.
5. Click **Go**. This will:
   - Create the `smart_supermarket` database
   - Create the `users`, `products`, and `sales` tables with proper foreign keys and indexes

   *(Alternative: open the "SQL" tab in phpMyAdmin and paste the contents of `schema.sql` directly, then click Go.)*

6. Confirm the database exists: in the left sidebar you should now see `smart_supermarket` with 3 tables inside it.

`db_config.py` already assumes the default XAMPP settings (`host: localhost`, `user: root`, `password: ""`). If your MySQL root user has a password set, update `db_config.py` accordingly.

---

## 3. Installing & Running the Project

```bash
# 1. Move into the project folder
cd smart_supermarket

# 2. (Recommended) create a virtual environment
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Make sure XAMPP's MySQL service is running (see Section 2)

# 5. Run the Streamlit app
streamlit run app.py
```

Browser automatically khulshe `http://localhost:8501` par. Jo na khule to manually te URL browser ma nakho.

---

## 4. How Each Module Works (Gujarati/Hinglish Explanation)

### `db_config.py`
Aa file ma MySQL ni connection details (host, user, password, database name) ek j jagyaye rakhi chhe. `get_connection()` function call karva thi navu connection male chhe. Jo XAMPP nu MySQL start na hoy to aa function friendly error message aape chhe, Python traceback nathi batavtu.

### `auth_utils.py`
Aa file ma teen main kaam chhe:
- **`register_user()`** — Shop name, username, mobile, email, password lai ne user ne database ma save kare chhe. Password kadi pan plain text ma store nathi thatu — `bcrypt.hashpw()` thi hash karine save thay chhe. Username ane email unique chhe ke nai te pehla check thay chhe.
- **`login_user()`** — Email + password lai ne verify kare chhe. `bcrypt.checkpw()` thi entered password ne stored hash sathe compare kare chhe. Sachu hoy to user no data (password hash sivay) session ma pass thay chhe.
- **`reset_password()`** — Email ane username banne match thata hoy to j password reset thay chhe — matlab koi bijana account no password koi badli na shake.

### `products.py`
Product-related badhu kaam ahi chhe — add, view (pandas DataFrame swarupe), edit, delete, ane low-stock detect karvu. **Dhyan rakho:** dareek query ma `user_id` check thay chhe, etle User A ne User B na products kadi na dekhay ke edit/delete na thay.

### `sales.py`
Sauthi important part `record_sale()` chhe. Jyare koi sale record thay:
1. Pehla product no available stock check thay chhe (`FOR UPDATE` lock sathe, jethi ek j samay ma be sale thay to bhul na thay)
2. Jo stock ochu hoy to error batave chhe
3. Sale amount ane profit calculate thay chhe (`Selling Price × Qty` ane `(Selling - Cost) × Qty`)
4. Stock ghatade chhe ane sales table ma navi row umere chhe — aa banne kaam **ek j transaction** ma thay chhe, etle stock ane sales record kadi pan out-of-sync na thay.

Bija functions (`get_revenue_over_time`, `get_top_selling_products`, `get_monthly_revenue`) Analytics page mate SQL thi grouped data pandas DataFrame swarupe pachi aape chhe.

### `translations.py`
Ek j `T` dictionary ma badhi Gujarati/English text rakhi chhe. `get_text(lang, key)` function call karta te bhasha ni text male chhe. Navi bhasha umerva mate bas navi key (jem ke `"hi"`) umervani, badhi files ma alag thi hard-code nathi karvu padtu.

### `app.py`
Aa main file badhane joде chhe. Streamlit na `session_state` ma logged-in user ane selected language store thay chhe. Login na thaay tyar sudhi Login/Register/Forgot-password tabs batave chhe; login thai gaya pachi sidebar ma navigation (Dashboard, Products, Sales, History, Analytics, Reports) male chhe. Dareek page potana function ma alag thi likhayeli chhe, jethi code samajva ma sarad rahe.

---

## 5. Testing Steps

1. **Register test:** Ek navu account banavo (shop name, username, mobile, email, password). Same username/email thi biju account banavva ni koshish karo — error avvi joie.
2. **Login test:** Sachi ane khoti password thi login try karo.
3. **Forgot password test:** Sachu email+username aapo, navo password set karo, pachi login karo.
4. **Product test:** 2-3 products add karo, ek product no quantity threshold thi ochu rakho — Dashboard par "Low Stock Alert" ma dekhavu joie.
5. **Sale test:** Ek product ni available quantity thi vadhare qty vechvani koshish karo — error avvi joie. Pachi sachi quantity thi sale record karo — stock automatically ghatvu joie, sales history ma navi entry dekhavi joie.
6. **Multi-user test:** Biju account banavo, login karo — pehla account na products/sales kadi na dekhay tevu confirm karo.
7. **Analytics/Reports test:** Charts load thay chhe ke nai, CSV download barabar thay chhe ke nai check karo.

---

## 6. Common Errors & Solutions

| Error | Karan | Ukel |
|---|---|---|
| `ConnectionError: Database connection failed` | XAMPP nu MySQL start nathi | XAMPP Control Panel ma MySQL start karo |
| `Unknown database 'smart_supermarket'` | Schema import nathi thayu | phpMyAdmin ma `database/schema.sql` import karo |
| `ModuleNotFoundError: No module named 'streamlit'` | Dependencies install nathi thayi | `pip install -r requirements.txt` chalavo |
| `Access denied for user 'root'@'localhost'` | MySQL root password `db_config.py` sathe match nathi thatu | `db_config.py` ma sachu password nakho |
| Login/Register form kaam nathi karto | MySQL connection band chhe athva table missing chhe | phpMyAdmin ma jai ne `users` table chhe ke nai check karo |
| `1062 Duplicate entry` error | Same username/email thi bijivar register karva ni koshish | Navu username/email vaparo — aa app pehla thi j aa check kare chhe pan direct DB manipulation thi aavi shake |

---

## 7. Future Enhancements (Not implemented — architecture-ready)

- Barcode scanning / QR code billing
- Online payment integration
- Automated invoice generation
- Cloud database migration
- Email/OTP-based password reset (currently username+email verification)
- AI-based sales prediction & demand forecasting
- Additional languages (just add a new key in `translations.py`)
