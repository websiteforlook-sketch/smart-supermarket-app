-- ==========================================================
-- Smart Supermarket Inventory & Sales Analytics System
-- Database Schema (import this through phpMyAdmin, or run in
-- the MySQL console that ships with XAMPP)
-- ==========================================================

CREATE DATABASE IF NOT EXISTS smart_supermarket
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE smart_supermarket;

-- ----------------------------------------------------------
-- users
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    shop_name     VARCHAR(150) NOT NULL,
    username      VARCHAR(80)  NOT NULL,
    mobile_no     VARCHAR(20)  NOT NULL,
    email         VARCHAR(150) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_users_username UNIQUE (username),
    CONSTRAINT uq_users_email UNIQUE (email)
) ENGINE=InnoDB;

-- ----------------------------------------------------------
-- products
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS products (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    user_id             INT NOT NULL,
    name                VARCHAR(150) NOT NULL,
    category            VARCHAR(80)  NOT NULL,
    price               DECIMAL(10,2) NOT NULL,   -- selling price
    cost_price          DECIMAL(10,2) NOT NULL,   -- purchase price
    quantity            INT NOT NULL DEFAULT 0,
    low_stock_threshold INT NOT NULL DEFAULT 5,
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_products_user FOREIGN KEY (user_id)
        REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_products_user (user_id)
) ENGINE=InnoDB;

-- ----------------------------------------------------------
-- sales
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS sales (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    user_id       INT NOT NULL,
    product_id    INT NOT NULL,
    quantity_sold INT NOT NULL,
    sale_amount   DECIMAL(10,2) NOT NULL,
    profit        DECIMAL(10,2) NOT NULL,
    sale_date     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_sales_user FOREIGN KEY (user_id)
        REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_sales_product FOREIGN KEY (product_id)
        REFERENCES products(id) ON DELETE CASCADE,
    INDEX idx_sales_user (user_id),
    INDEX idx_sales_date (sale_date)
) ENGINE=InnoDB;
