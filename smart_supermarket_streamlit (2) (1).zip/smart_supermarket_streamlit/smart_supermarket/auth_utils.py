
"""
auth_utils.py
-------------
User registration, login and password-reset logic.
All queries are parameterized (no string concatenation of user input).
Passwords are always stored using Bcrypt — never plain text.
"""
 
import re
import bcrypt
from mysql.connector import Error
from db_config import get_connection
 
 
# ---------------------------------------------------------- validation ----
 
def is_valid_email(email: str) -> bool:
    pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    return bool(re.match(pattern, email or ""))
 
 
def is_valid_mobile(mobile: str) -> bool:
    return bool(re.match(r"^[0-9]{10}$", (mobile or "").strip()))
 
 
# -------------------------------------------------------- password hash ----
 
def hash_password(plain_password: str) -> str:
    return bcrypt.hashpw(plain_password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
 
 
def check_password(plain_password: str, password_hash: str) -> bool:
    try:
        return bcrypt.checkpw(plain_password.encode("utf-8"), password_hash.encode("utf-8"))
    except ValueError:
        return False
 
 
# -------------------------------------------------------------- register ----
 
def register_user(shop_name: str, username: str, mobile_no: str, email: str, password: str):
    """
    Returns (success: bool, message: str)
    """
    shop_name = (shop_name or "").strip()
    username = (username or "").strip()
    mobile_no = (mobile_no or "").strip()
    email = (email or "").strip().lower()
 
    if not shop_name or not username or not mobile_no or not email or not password:
        return False, "All fields are required."
 
    if not is_valid_mobile(mobile_no):
        return False, "Please enter a valid 10-digit mobile number."
 
    if not is_valid_email(email):
        return False, "Please enter a valid email address."
 
    if len(password) < 6:
        return False, "Password must be at least 6 characters long."
 
    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor()
 
        # Uniqueness checks
        cursor.execute("SELECT id FROM users WHERE username = %s", (username,))
        if cursor.fetchone():
            return False, "This username is already taken."
 
        cursor.execute("SELECT id FROM users WHERE email = %s", (email,))
        if cursor.fetchone():
            return False, "An account with this email already exists."
 
        password_hash = hash_password(password)
        cursor.execute(
            """
            INSERT INTO users (shop_name, username, mobile_no, email, password_hash)
            VALUES (%s, %s, %s, %s, %s)
            """,
            (shop_name, username, mobile_no, email, password_hash),
        )
        conn.commit()
        return True, "Account created successfully. Please log in."
 
    except Error as e:
        return False, f"Database error while registering: {e}"
    except ConnectionError as e:
        return False, str(e)
    finally:
        if conn is not None and conn.is_connected():
            conn.close()
 
 
# ----------------------------------------------------------------- login ----
 
def login_user(email: str, password: str):
    """
    Returns (success: bool, message: str, user: dict | None)
    """
    email = (email or "").strip().lower()
 
    if not email or not password:
        return False, "Please enter both email and password.", None
 
    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
        user = cursor.fetchone()
 
        if not user:
            return False, "No account found with this email.", None
 
        if not check_password(password, user["password_hash"]):
            return False, "Incorrect password.", None
 
        # Don't carry the hash around in session state
        user.pop("password_hash", None)
        return True, "Login successful.", user
 
    except Error as e:
        return False, f"Database error while logging in: {e}", None
    except ConnectionError as e:
        return False, str(e), None
    finally:
        if conn is not None and conn.is_connected():
            conn.close()
 
 
# --------------------------------------------------------- reset password ----
 
def reset_password(email: str, username: str, new_password: str):
    """
    Verifies that email + username belong to the same account, then
    updates the password. Returns (success: bool, message: str)
    """
    email = (email or "").strip().lower()
    username = (username or "").strip()
 
    if not email or not username or not new_password:
        return False, "All fields are required."
 
    if len(new_password) < 6:
        return False, "New password must be at least 6 characters long."
 
    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute(
            "SELECT id FROM users WHERE email = %s AND username = %s",
            (email, username),
        )
        user = cursor.fetchone()
 
        if not user:
            return False, "No account matches that email and username combination."
 
        new_hash = hash_password(new_password)
        cursor.execute(
            "UPDATE users SET password_hash = %s WHERE id = %s",
            (new_hash, user["id"]),
        )
        conn.commit()
        return True, "Password updated successfully. Please log in."
 
    except Error as e:
        return False, f"Database error while resetting password: {e}"
    except ConnectionError as e:
        return False, str(e)
    finally:
        if conn is not None and conn.is_connected():
            conn.close()
 
 
# ---------------------------------------------------------- update profile ----
 
def update_profile(user_id, shop_name: str, mobile_no: str, email: str):
    """
    Updates shop_name, mobile_no and email for the given user_id.
    Returns (success: bool, message: str, updated_user: dict | None)
    """
    shop_name = (shop_name or "").strip()
    mobile_no = (mobile_no or "").strip()
    email = (email or "").strip().lower()
 
    if not shop_name or not mobile_no or not email:
        return False, "All fields are required.", None
 
    if not is_valid_mobile(mobile_no):
        return False, "Please enter a valid 10-digit mobile number.", None
 
    if not is_valid_email(email):
        return False, "Please enter a valid email address.", None
 
    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor(dictionary=True)
 
        # Email must stay unique (excluding this user's own current row)
        cursor.execute(
            "SELECT id FROM users WHERE email = %s AND id != %s", (email, user_id)
        )
        if cursor.fetchone():
            return False, "This email is already used by another account.", None
 
        cursor.execute(
            "UPDATE users SET shop_name = %s, mobile_no = %s, email = %s WHERE id = %s",
            (shop_name, mobile_no, email, user_id),
        )
        conn.commit()
 
        cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
        updated_user = cursor.fetchone()
        updated_user.pop("password_hash", None)
        return True, "Profile updated successfully.", updated_user
 
    except Error as e:
        return False, f"Database error while updating profile: {e}", None
    except ConnectionError as e:
        return False, str(e), None
    finally:
        if conn is not None and conn.is_connected():
            conn.close()
 
 
# --------------------------------------------------------- change password ----
 
def change_password(user_id, current_password: str, new_password: str):
    """
    Verifies the current password before setting a new one.
    Returns (success: bool, message: str)
    """
    if not current_password or not new_password:
        return False, "Please fill in both password fields."
 
    if len(new_password) < 6:
        return False, "New password must be at least 6 characters long."
 
    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
        user = cursor.fetchone()
 
        if not user:
            return False, "Account not found."
 
        if not check_password(current_password, user["password_hash"]):
            return False, "Current password is incorrect."
 
        new_hash = hash_password(new_password)
        cursor.execute(
            "UPDATE users SET password_hash = %s WHERE id = %s", (new_hash, user_id)
        )
        conn.commit()
        return True, "Password changed successfully."
 
    except Error as e:
        return False, f"Database error while changing password: {e}"
    except ConnectionError as e:
        return False, str(e)
    finally:
        if conn is not None and conn.is_connected():
            conn.close()
 
 
# --------------------------------------------------------- profile picture ----
 
def update_profile_picture(user_id, image_bytes: bytes):
    """
    Saves the (already-resized) image bytes into the users.profile_pic column.
    Returns (success: bool, message: str)
    """
    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE users SET profile_pic = %s WHERE id = %s",
            (image_bytes, user_id),
        )
        conn.commit()
        return True, "Profile picture updated successfully."
    except Error as e:
        return False, f"Database error while updating profile picture: {e}"
    except ConnectionError as e:
        return False, str(e)
    finally:
        if conn is not None and conn.is_connected():
            conn.close()
 
