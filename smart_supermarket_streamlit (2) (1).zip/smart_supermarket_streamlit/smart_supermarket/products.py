"""
products.py
-----------
Product management: add, view, edit, delete, low-stock detection.
Every function is scoped to a user_id so users only ever touch
their own inventory.
"""

import pandas as pd
from mysql.connector import Error
from db_config import get_connection


def add_product(user_id, name, category, price, cost_price, quantity, low_stock_threshold):
    """
    Returns (success: bool, message: str)
    """
    name = (name or "").strip()
    category = (category or "").strip()

    if not name:
        return False, "Product name is required."
    if not category:
        return False, "Category is required."
    try:
        price = float(price)
        cost_price = float(cost_price)
        quantity = int(quantity)
        low_stock_threshold = int(low_stock_threshold)
    except (TypeError, ValueError):
        return False, "Price, cost price, quantity and threshold must be numbers."

    if price < 0 or cost_price < 0:
        return False, "Price cannot be negative."
    if quantity < 0:
        return False, "Quantity cannot be negative."
    if low_stock_threshold < 0:
        return False, "Low stock threshold cannot be negative."

    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO products (user_id, name, category, price, cost_price, quantity, low_stock_threshold)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            """,
            (user_id, name, category, price, cost_price, quantity, low_stock_threshold),
        )
        conn.commit()
        return True, "Product added successfully."
    except Error as e:
        return False, f"Database error while adding product: {e}"
    except ConnectionError as e:
        return False, str(e)
    finally:
        if conn is not None and conn.is_connected():
            conn.close()


def get_products(user_id) -> pd.DataFrame:
    """
    Returns a DataFrame of all products belonging to this user.
    Columns: id, name, category, price, cost_price, quantity,
             low_stock_threshold, is_low_stock
    """
    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute(
            """
            SELECT id, name, category, price, cost_price, quantity, low_stock_threshold
            FROM products WHERE user_id = %s ORDER BY name
            """,
            (user_id,),
        )
        rows = cursor.fetchall()
        df = pd.DataFrame(rows)
        if not df.empty:
            df["is_low_stock"] = df["quantity"] <= df["low_stock_threshold"]
        return df
    except (Error, ConnectionError):
        return pd.DataFrame()
    finally:
        if conn is not None and conn.is_connected():
            conn.close()


def get_product_by_id(product_id, user_id):
    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute(
            "SELECT * FROM products WHERE id = %s AND user_id = %s",
            (product_id, user_id),
        )
        return cursor.fetchone()
    except (Error, ConnectionError):
        return None
    finally:
        if conn is not None and conn.is_connected():
            conn.close()


def update_product(product_id, user_id, name, category, price, cost_price, quantity, low_stock_threshold):
    """
    Returns (success: bool, message: str). Only updates if the product
    belongs to the given user_id.
    """
    try:
        price = float(price)
        cost_price = float(cost_price)
        quantity = int(quantity)
        low_stock_threshold = int(low_stock_threshold)
    except (TypeError, ValueError):
        return False, "Price, cost price, quantity and threshold must be numbers."

    if price < 0 or cost_price < 0 or quantity < 0 or low_stock_threshold < 0:
        return False, "Values cannot be negative."

    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            UPDATE products
            SET name = %s, category = %s, price = %s, cost_price = %s,
                quantity = %s, low_stock_threshold = %s
            WHERE id = %s AND user_id = %s
            """,
            (name, category, price, cost_price, quantity, low_stock_threshold, product_id, user_id),
        )
        conn.commit()
        if cursor.rowcount == 0:
            return False, "Product not found or you don't have permission to edit it."
        return True, "Product updated successfully."
    except Error as e:
        return False, f"Database error while updating product: {e}"
    except ConnectionError as e:
        return False, str(e)
    finally:
        if conn is not None and conn.is_connected():
            conn.close()


def delete_product(product_id, user_id):
    """
    Returns (success: bool, message: str). Only deletes if the product
    belongs to the given user_id.
    """
    conn = None
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "DELETE FROM products WHERE id = %s AND user_id = %s",
            (product_id, user_id),
        )
        conn.commit()
        if cursor.rowcount == 0:
            return False, "Product not found or you don't have permission to delete it."
        return True, "Product deleted successfully."
    except Error as e:
        return False, f"Database error while deleting product: {e}"
    except ConnectionError as e:
        return False, str(e)
    finally:
        if conn is not None and conn.is_connected():
            conn.close()


def get_low_stock_products(user_id) -> pd.DataFrame:
    df = get_products(user_id)
    if df.empty:
        return df
    return df[df["is_low_stock"]]
